
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexwonderland.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.alexwonderland.block.TakeItEasyPillowBlock;
import net.mcreator.alexwonderland.block.RubrubikscubeBlock;
import net.mcreator.alexwonderland.block.BedBlock;
import net.mcreator.alexwonderland.block.AlexLeavesBlock;
import net.mcreator.alexwonderland.block.AlexLavaBlock;
import net.mcreator.alexwonderland.block.AlexGrassBlock;
import net.mcreator.alexwonderland.block.AlexDirtBlock;
import net.mcreator.alexwonderland.AlexWonderlandMod;

public class AlexWonderlandModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, AlexWonderlandMod.MODID);
	public static final DeferredHolder<Block, Block> ALEX_GRASS = REGISTRY.register("alex_grass", () -> new AlexGrassBlock());
	public static final DeferredHolder<Block, Block> ALEX_DIRT = REGISTRY.register("alex_dirt", () -> new AlexDirtBlock());
	public static final DeferredHolder<Block, Block> ALEX_LEAVES = REGISTRY.register("alex_leaves", () -> new AlexLeavesBlock());
	public static final DeferredHolder<Block, Block> ALEX_LAVA = REGISTRY.register("alex_lava", () -> new AlexLavaBlock());
	public static final DeferredHolder<Block, Block> RUBRUBIKSCUBE = REGISTRY.register("rubrubikscube", () -> new RubrubikscubeBlock());
	public static final DeferredHolder<Block, Block> TAKE_IT_EASY_PILLOW = REGISTRY.register("take_it_easy_pillow", () -> new TakeItEasyPillowBlock());
	public static final DeferredHolder<Block, Block> BED = REGISTRY.register("bed", () -> new BedBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			AlexGrassBlock.blockColorLoad(event);
			AlexLeavesBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			AlexLeavesBlock.itemColorLoad(event);
		}
	}
}
