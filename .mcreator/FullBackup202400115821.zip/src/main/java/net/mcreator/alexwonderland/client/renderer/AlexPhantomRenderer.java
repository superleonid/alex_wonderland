
package net.mcreator.alexwonderland.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.alexwonderland.entity.AlexPhantomEntity;
import net.mcreator.alexwonderland.client.model.Modelalexphantom;

public class AlexPhantomRenderer extends MobRenderer<AlexPhantomEntity, Modelalexphantom<AlexPhantomEntity>> {
	public AlexPhantomRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelalexphantom(context.bakeLayer(Modelalexphantom.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(AlexPhantomEntity entity) {
		return new ResourceLocation("alex_wonderland:textures/entities/phantom.png");
	}
}
