
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexwonderland.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.alexwonderland.AlexWonderlandMod;

public class AlexWonderlandModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, AlexWonderlandMod.MODID);
	public static final DeferredHolder<Item, Item> ALEX_GRASS = block(AlexWonderlandModBlocks.ALEX_GRASS);
	public static final DeferredHolder<Item, Item> ALEX_DIRT = block(AlexWonderlandModBlocks.ALEX_DIRT);
	public static final DeferredHolder<Item, Item> ALEX_LEAVES = block(AlexWonderlandModBlocks.ALEX_LEAVES);
	public static final DeferredHolder<Item, Item> LAVA_PET_SPAWN_EGG = REGISTRY.register("lava_pet_spawn_egg", () -> new DeferredSpawnEggItem(AlexWonderlandModEntities.LAVA_PET, -6750004, -10027009, new Item.Properties()));
	public static final DeferredHolder<Item, Item> ALEX_PHANTOM_SPAWN_EGG = REGISTRY.register("alex_phantom_spawn_egg", () -> new DeferredSpawnEggItem(AlexWonderlandModEntities.ALEX_PHANTOM, -52429, -3407617, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
