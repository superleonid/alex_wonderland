
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexwonderland.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.alexwonderland.AlexWonderlandMod;

public class AlexWonderlandModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AlexWonderlandMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> ALEX_TAB = REGISTRY.register("alex_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.alex_wonderland.alex_tab")).icon(() -> new ItemStack(AlexWonderlandModBlocks.ALEX_GRASS.get())).displayItems((parameters, tabData) -> {
				tabData.accept(AlexWonderlandModBlocks.ALEX_DIRT.get().asItem());
				tabData.accept(AlexWonderlandModBlocks.ALEX_GRASS.get().asItem());
				tabData.accept(AlexWonderlandModBlocks.ALEX_LEAVES.get().asItem());
				tabData.accept(AlexWonderlandModItems.LAVA_PET_SPAWN_EGG.get());
				tabData.accept(AlexWonderlandModItems.ALEX_PHANTOM_SPAWN_EGG.get());
			}).withSearchBar().build());
}
